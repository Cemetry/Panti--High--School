# KUET-redesigned
[Left incomplete] A redesigned version of kuet website. Tried to implement material design. At least it is better then the official website which is implemented with table.
